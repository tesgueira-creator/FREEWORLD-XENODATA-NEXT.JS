#!/usr/bin/env ts-node
/*
 * validate-datasets.ts
 *
 * This script performs a number of validations on the public points of interest CSV
 * included in this repository.  It checks that each record uses an allowed category,
 * has a license, uses a valid precision value, and respects coordinate precision
 * guidelines for approximate locations.  If any issues are found the script exits
 * with a non-zero status code.
 *
 * To run this script install dependencies and execute:
 *
 *   npx ts-node scripts/validate-datasets.ts
 *
 */

import * as fs from 'fs';
import * as path from 'path';
import { parse } from 'csv-parse/sync';

type CsvRecord = {
  category: string;
  name: string;
  description: string;
  country: string;
  region_or_state: string;
  latitude: string;
  longitude: string;
  precision: string;
  source_url: string;
  notes: string;
  license: string;
  status: string;
  last_verified: string;
};

const allowedCategories = [
  'anomalous_zone',
  'historical_case_site',
  'research_facility_public',
  'observatory',
  'paranormal_site',
  'archaeological_site',
  'geological_site',
  'mystery_zone',
  'missing_cluster',
  'reported_abduction_site',
  'paranormal_cluster',
  'cattle_mutilation_region',
  'meteorite_fall_site',
  'dark_sky_reserve',
  'aurora_viewing_site',
  'radio_quiet_zone',
  'folklore_legend_site',
  'sky_quality_site',
  'transient_luminous_event_study_site',
  'earthquake_lights_region',
  'ball_lightning_reports_region',
  'atmospheric_glow_region',
  'historic_airship_sighting_region',
  'legend_water_creature_lake',
  'impact_structure',
  'rare_cloud_phenomena_region',
  'noctilucent_cloud_observation_site',
  'luminous_plankton_bay',
  'gravity_anomaly_site',
  'geomagnetic_anomaly_region',
  'radioastronomy_pathfinder',
  'ionospheric_heater_public',
  'magnetometer_array_site',
  'open_science_sensor_network',
  'uap_data_collection_initiative',
  'meteoritic_recovery_area',
  'comet_impact_structure_candidate',
  'historic_space_event_observation_site',
];

const allowedPrecisions = ['exact', 'approx', 'regional'];

function validate() {
  const csvPath = path.join(__dirname, '..', 'data', 'points_of_interest.public.en.csv');
  const csvContent = fs.readFileSync(csvPath, 'utf-8');
  const records: CsvRecord[] = parse(csvContent, {
    columns: true,
    skip_empty_lines: true,
    comment: '#',
    trim: true,
  });

  let errors: string[] = [];
  let warnings: string[] = [];

  records.forEach((row, idx) => {
    const identifier = `${row.name} (line ${idx + 2})`;

    // Check category
    if (!allowedCategories.includes(row.category)) {
      errors.push(
        `${identifier}: invalid category '${row.category}'. Expected one of ${allowedCategories.join(
          ', '
        )}`
      );
    }

    // Check precision
    if (!allowedPrecisions.includes(row.precision)) {
      errors.push(
        `${identifier}: invalid precision '${row.precision}'. Expected one of ${allowedPrecisions.join(
          ', '
        )}`
      );
    }

    // Check license
    if (!row.license || row.license.trim().length === 0) {
      errors.push(`${identifier}: missing license`);
    }

    // Check coordinates
    const lat = parseFloat(row.latitude);
    const lon = parseFloat(row.longitude);
    if (isNaN(lat) || isNaN(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
      errors.push(`${identifier}: invalid latitude/longitude`);
    }
    // If approximate precision, ensure no more than 3 decimal places
    if (row.precision !== 'exact') {
      const latDecimals = row.latitude.split('.')[1]?.length || 0;
      const lonDecimals = row.longitude.split('.')[1]?.length || 0;
      if (latDecimals > 3 || lonDecimals > 3) {
        warnings.push(
          `${identifier}: coordinate precision (${latDecimals},${lonDecimals}) exceeds 3 decimals for approximate/regional data`
        );
      }
    }
  });

  if (warnings.length > 0) {
    console.warn('Warnings:');
    warnings.forEach((w) => console.warn('  -', w));
  }
  if (errors.length > 0) {
    console.error('Errors:');
    errors.forEach((e) => console.error('  -', e));
    console.error(`\nValidation failed with ${errors.length} error(s).`);
    process.exit(1);
  }
  console.log(`Validation completed successfully for ${records.length} record(s).`);
}

validate();