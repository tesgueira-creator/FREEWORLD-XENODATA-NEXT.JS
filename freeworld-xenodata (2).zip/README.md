# FreeWorld Xenodata

This repository contains an initial skeleton for the **FreeWorld Xenodata** platform.  
The goal of the project is to provide a transparent, ethical and performant portal for
exploring anomalous phenomena, historical cases, scientific events and
contextual datasets.  It follows the technical and editorial guidelines outlined in
the accompanying specification provided by the user.

## Project structure

```
freeworld-xenodata/
├── app/                 # Next.js 15 App Router directory
│   ├── layout.tsx       # Root layout with global metadata and HTML scaffold
│   ├── page.tsx         # Home page listing a few sample points of interest
│   └── globals.css      # Minimal global styles
├── data/
│   ├── pointsOfInterest.ts   # Sample subset of points of interest used by the home page
│   └── points_of_interest.public.en.csv  # Full CSV dataset (public and non‑sensitive)
├── types/
│   └── index.ts        # Type definitions for the data structures
├── next.config.js      # Next.js configuration enabling the experimental app directory
├── package.json        # Dependency manifest and scripts
├── tsconfig.json       # TypeScript configuration
└── README.md           # This file
```

## Getting started

1. **Install dependencies**

   Use your preferred package manager to install dependencies.  For example, with npm:

   ```bash
   npm install
   ```

2. **Run the development server**

   ```bash
   npm run dev
   ```

   Then open [http://localhost:3000](http://localhost:3000) in your browser.  You should see
   the welcome page and a list of sample points of interest.

3. **Load the full dataset**

   The `data/pointsOfInterest.ts` file contains a small sample for demonstration.  To use
   the complete dataset, parse `data/points_of_interest.public.en.csv` during build or runtime
   and convert it to a JSON/TS module.  You can use a utility like
   [`csv-parse`](https://www.npmjs.com/package/csv-parse) or write a custom script to convert
   it into the `PointOfInterest` type defined in `types/index.ts`.

4. **Validate your datasets**

   Before committing new locations to version control you can validate the CSV using the
   included script:

   ```bash
   npx ts-node scripts/validate-datasets.ts
   ```

   The script checks that categories are allowed, licenses are present and coordinate precision
   conforms to the rules defined in the specification.  If it detects any errors it will exit
   with a non‑zero status code and list the offending rows.

5. **Placeholder scripts for analytics**

   The `scripts/recompute-analytics.ts` file is a stub for recomputing materialized views and
   other derived analytics.  Once your PostgreSQL schema and materialized views are in place,
   implement this script to connect to the database and trigger the appropriate `REFRESH`
   commands or stored procedures.

## Next steps

This repository is a starting point.  According to the full specification, you will want to:

* Implement additional pages such as the interactive map, timeline, case listings and analytics.
* Set up a Postgres database with PostGIS and integrate it via Drizzle ORM.
* Build data ingestion and ETL pipelines to validate, normalise, enrich and deduplicate source data.
* Add observability (OpenTelemetry), caching layers and edge runtime where appropriate.
* Implement accessibility and internationalisation (i18n) features.

The specification document `FreeWorld Xenodata – Especificação Mestre do Website` should be
used as the source of truth as you evolve this codebase.