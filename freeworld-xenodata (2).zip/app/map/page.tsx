/**
 * Map page stub
 *
 * This page demonstrates how you might structure a dedicated page for the
 * interactive map.  Currently it displays a background image and placeholder
 * content.  Replace the placeholder with a proper map component (e.g. using
 * Leaflet or Deck.gl) once you integrate the necessary client‑side libraries.
 */
export default function MapPage() {
  return (
    <div
      style={{
        minHeight: '100vh',
        backgroundImage: "url('/images/section_map.png')",
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        padding: '4rem 2rem',
        color: 'white',
      }}
    >
      <h1 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Interactive Map</h1>
      <p>Map functionality will appear here soon.</p>
    </div>
  );
}