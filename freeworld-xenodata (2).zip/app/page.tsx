import { pointsOfInterest } from '../data/pointsOfInterest';

/**
 * The home page introduces the platform and lists a few sample points of interest.
 * This is a simple static component to demonstrate data loading and server components.
 */
export default function HomePage() {
  return (
    <>
      {/* Hero section with abstract background */}
      <section
        style={{
          backgroundImage: "url('/images/hero_primary.png')",
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          color: 'white',
          padding: '4rem 2rem',
        }}
      >
        <h1 style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>
          Welcome to FreeWorld&nbsp;Xenodata
        </h1>
        <p style={{ maxWidth: '40rem', lineHeight: 1.5 }}>
          Explore anomalous zones, historical cases, research facilities and other scientifically
          interesting locations around the world.  This platform is built with Next.js using
          React Server Components and designed for high performance and accessibility.
        </p>
      </section>
      {/* Content section */}
      <main style={{ padding: '2rem' }}>
        <h2 style={{ fontSize: '1.8rem', marginBottom: '0.75rem' }}>Sample Points of Interest</h2>
        <ul>
          {pointsOfInterest.slice(0, 5).map((poi) => (
            <li key={poi.name} style={{ marginBottom: '0.5rem' }}>
              <strong>{poi.name}</strong> (<em>{poi.category}</em> – {poi.country})
            </li>
          ))}
        </ul>
      </main>
    </>
  );
}