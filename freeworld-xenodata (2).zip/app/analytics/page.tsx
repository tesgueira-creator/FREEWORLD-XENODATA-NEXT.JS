/**
 * Analytics page stub
 *
 * This page displays a simple static chart generated from the points of interest
 * dataset.  In a complete implementation you would replace this static image
 * with interactive chart components driven by real analytics data from your
 * backend or materialized views.
 */
export default function AnalyticsPage() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Analytics Overview</h1>
      <p>
        Explore key metrics and visualisations derived from the points of interest dataset.
        The bar chart below shows the top categories by count.
      </p>
      <img
        src="/images/sample_chart.png"
        alt="Sample chart of top categories"
        style={{ maxWidth: '100%', height: 'auto', marginTop: '1rem' }}
      />
    </main>
  );
}