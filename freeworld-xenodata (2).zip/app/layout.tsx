import './globals.css';
import type { Metadata } from 'next';
import { ReactNode } from 'react';

/**
 * Root layout provides basic HTML scaffolding for all pages.  
 * It also defines global metadata used by Next.js for SEO.
 */
export const metadata: Metadata = {
  title: {
    default: 'FreeWorld Xenodata',
    template: '%s | FreeWorld Xenodata',
  },
  description:
    'A platform for exploring and analyzing anomalous phenomena, historical cases and geospatial data.',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        {/* Simple navigation bar */}
        <header
          style={{
            display: 'flex',
            gap: '1rem',
            alignItems: 'center',
            padding: '1rem 2rem',
            backgroundColor: '#0f172a',
            color: 'white',
          }}
        >
          <a href="/" style={{ fontWeight: 600, textDecoration: 'none', color: 'white' }}>
            Xenodata
          </a>
          <nav style={{ display: 'flex', gap: '1rem' }}>
            <a href="/" style={{ textDecoration: 'none', color: 'white' }}>
              Home
            </a>
            <a href="/map" style={{ textDecoration: 'none', color: 'white' }}>
              Map
            </a>
            <a href="/analytics" style={{ textDecoration: 'none', color: 'white' }}>
              Analytics
            </a>
          </nav>
        </header>
        {children}
      </body>
    </html>
  );
}