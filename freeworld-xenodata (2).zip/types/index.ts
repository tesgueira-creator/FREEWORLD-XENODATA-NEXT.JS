/**
 * A point of interest is a public location associated with anomalous phenomena, historic events,
 * research infrastructure or other categories defined in the data specification.  
 * Fields correspond directly to the columns of the CSV supplied in this repository.
 */
export type PointOfInterest = {
  category: string;
  name: string;
  description: string;
  country: string;
  region_or_state: string | null;
  latitude: number | null;
  longitude: number | null;
  precision: 'exact' | 'approx' | 'regional';
  source_url: string;
  notes: string;
  license: string;
  status: string;
  last_verified: string;
};